# BotApaJa
BOT WHATSAPP HP ApaJa Recode Dari Bintang Nur Pradana

### Alat dan Bahan
Siapin alat dan bahannya.
```bash
> niat
> 2 handphone (1 buat jalanin sc, 1 buat scan qr)
> internet yang memadai, kalo lu gapunya kuota pake kuota kemendikbud ae
> aplikasi whatsapp
> aplikasi termux
> kopi
```

### Cara Installnya
Sebelum lu jalanin sc nya install dulu lah.
```bash
> kalo lu belum punya apk termux, download di playstore
> masuk ke apk termux lalu ketik dibawah ini!
> git clone https://github.com/ApaJaReal/SenBot
> cd SenBot
> bash install.sh
> node index.js
> Tinggal scan qr dah
```

## Features

| st4rz BOT       |                Feature           |
| :-----------: | :--------------------------------: |
|       ✅       | Sticker Creator                  |
|       ✅       | Magernulis                       |
|       ✅       | Pantun                           |
|       ✅       | Youtube Downloader               |
|       ✅       | Quotes                           |
|       ✅       | Anime                            |
|       ✅       | Suara Google                     |
|       ✅       | Quran                            |
|       ✅       | Youtube MP3 Downloader           |
|       ✅       | Intagram Downloader              |
|       ✅       | Twitter Downloader               |
|       ✅       | Facebook Downloader              |
|       ✅       | Wikipedia                        |
|       ✅       | Say                              |
|       ✅       | Info/termux-whatsapp-bot)


